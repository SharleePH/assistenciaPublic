-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: asistencia
-- ------------------------------------------------------
-- Server version	5.7.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=56 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (1,'Susana Luciano',1),(2,'Cristina Diaz',1),(3,'Efren Ayala',1),(4,'Gabriela Ponce',1),(5,'Carlos Joel Gomez Barajas',1),(6,'Jose Servin',1),(7,'Octavio Castro',1),(8,'Sara Delgadillo',1),(9,'Jorge Elizalde',1),(10,'Rocio Ruiz',1),(11,'Magdalena Lopez',1),(12,'Jorge Vega',1),(13,'Martha Orozco',1),(14,'Luz Vargas',1),(15,'Angel Calderon',1),(16,'Luis Gonzalez',1),(17,'Carlos Jimenez',1),(18,'Jennifer Cabral',1),(19,'Esmeralda Acosta',1),(52,'Elida Gallegos',1),(21,'Edgar Benitez',1),(22,'Alejandro Gil',1),(23,'Rolando Sosa',1),(24,'Martin Lopez',1),(25,'Maria Barron',1),(26,'Gaston Rodriguez',1),(27,'Alfonso Garcia',1),(28,'Fernando Hernandez',1),(29,'Erendida Munoz',1),(30,'Oscar Lomeli',1),(31,'Alvaro Aragon',1),(32,'Ana Lucia Alvarado',1),(33,'Gloria Gonzalez',1),(34,'Dulce Vazquez',1),(35,'Gladys Castorena',1),(36,'Guadalupe Herrada',1),(37,'Juan Dominguez',1),(38,'Juan Vargas',1),(39,'Karina Garcia',1),(40,'Marisol Martinez',1),(41,'Maria de Jesus Padilla Mendez',1),(42,'Zaira Castillo',1),(43,'Sergio Jimenez',1),(44,'Angeles Godoy',1),(45,'Arturo Guardado',1),(46,'Briseyda Diaz',1),(47,'Federico Aguila',1),(48,'Hugo Valdivia',1),(49,'Jocelyn Plascencia',1),(50,'Jorge Barron',1),(51,'Monica Barajas',1),(53,'Oscar Delgadillo',1),(54,'Lucia Calderon',1),(55,'Diana Maria Ibarra Benitez',1);
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-23 14:42:41
