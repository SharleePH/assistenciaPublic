-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: asistencia
-- ------------------------------------------------------
-- Server version	5.7.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cursos`
--

DROP TABLE IF EXISTS `cursos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cursos` (
  `idCurso` int(11) NOT NULL AUTO_INCREMENT,
  `idTipoCurso` int(11) NOT NULL,
  `nombreCurso` varchar(200) NOT NULL,
  `idProveedor` int(11) NOT NULL,
  `fechaInicial` datetime NOT NULL,
  `fechaFinal` datetime NOT NULL,
  `descripcionCurso` varchar(500) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`idCurso`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cursos`
--

LOCK TABLES `cursos` WRITE;
/*!40000 ALTER TABLE `cursos` DISABLE KEYS */;
INSERT INTO `cursos` VALUES (1,2,'Demo WorkDay',1,'2022-02-16 10:00:00','2022-02-16 13:00:00','asd  dsafasdf asdfa fasdf sdf',1),(2,1,'Demo Oracle Back Office',2,'2022-02-17 10:00:00','2022-02-17 13:00:00','',1),(3,3,'Demo Oracle BI',2,'2022-02-17 13:00:00','2022-02-17 14:00:00','',1),(4,2,'Hospisoft (His)',3,'2022-02-22 09:00:00','2022-02-22 12:00:00','',1),(5,1,'Hospisoft (Back)',3,'2022-02-22 14:00:00','2022-02-22 17:00:00','',1),(6,3,'Hospisoft (BI)',3,'2022-02-22 17:00:00','2022-02-22 18:00:00','',1),(7,2,'SAP / CERNER (HIS)',4,'2022-03-01 09:00:00','2022-03-01 00:59:00','',1),(8,1,'SAP / CERNER (BACK OFFICE)',4,'2022-03-01 14:00:00','2022-03-01 17:00:00','',1),(9,3,'SAP / CERNER (BI)',4,'2022-03-01 17:00:00','2022-03-01 18:00:00','',1),(10,2,'Tasy (HIS)',5,'2022-03-03 09:00:00','2022-03-03 12:00:00','',1),(11,1,'Tasy (BACKOFFICE)',5,'2022-03-03 14:00:00','2022-03-03 17:00:00','',1),(12,3,'Tasy (BI)',5,'2022-03-03 17:00:00','2022-03-03 18:00:00','',1),(13,2,'Commons (HIS)',6,'2022-02-24 09:00:00','2022-02-24 12:00:00','',1);
/*!40000 ALTER TABLE `cursos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-23 14:42:41
